// Dashboard placeholder
console.log('TI-Verde Dashboard');